Furkan Demir 21802818
Muzaffer Köksal 21803125

To succesfully run the both models, you need Python3 installed with the packages installed from requirements.txt