import cv2
import testing
from testing import Tester
from skimage import color
import numpy as np
import sys

img = cv2.imread(str(sys.argv[1]))
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

ret, gray = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

kernel = np.ones((5,5), np.uint8)
gray = cv2.morphologyEx(gray, cv2.MORPH_OPEN, kernel)
#gray = cv2.erode(gray, kernel, iterations=2)
cv2.imshow("gray",gray)
cv2.waitKey(1000)
ctrs = cv2.findContours(gray.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)[0]
sorted_ctrs = sorted(ctrs, key=lambda ctr: cv2.boundingRect(ctr)[0])
old_x = 0
old_y = 0
old_x_w = sorted_ctrs[0:1][0][2][0][0] +1
old_y_h = sorted_ctrs[0:1][0][2][0][1] + 1
start = 0
tester = Tester()
bound_y, bound_x = gray.shape
for i, ctr in enumerate(sorted_ctrs):
    x, y, w, h = cv2.boundingRect(ctr)
    roi = img[y:y + h, x:x + w]

    area = w*h

    if 0 < area < 200000 and start > 0:
        if not(x > old_x and y > old_y and (x+w) < old_x_w and (y+h) < old_y_h):
            rect = cv2.rectangle(gray, (x - 6, y - 6), (x + w + 6, y + h + 6), (0, 255, 0), 2)
            #padded = gray[y:y+h,x:x+w]
            #padded = np.pad(padded, 
            #    pad_width = 4, 
            #    mode = 'maximum') # or mode = "maximum' for a white border
            #padded = cv2.resize(padded, (28,28), interpolation=cv2.INTER_LINEAR)
            cv2.imwrite("letter.jpg", gray[y-6:y+h+6,x-6:x+w+6])
            #cv2.imshow("padded",padded)
            cv2.waitKey(1000)
            print('out : ' , tester.predict('letter'))
            cv2.imshow('ASD',rect)
       
        if start == 1:
            rect = cv2.rectangle(gray, (x-6, y-6), (x + w+6, y + h + 6), (0, 255, 0), 2)
            #padded = gray[y:y+h,x:x+w]
            #padded = np.pad(padded, 
            #    pad_width = 4, 
            #    mode = 'maximum') # or mode = "maximum' for a white border
            #padded = cv2.resize(padded, (28,28), interpolation=cv2.INTER_LINEAR)
            cv2.imwrite("letter.jpg", gray[y-6:y+h+6,x-6:x+w+6])
            #cv2.imshow("padded",padded)
            cv2.waitKey(1000)
            print('out : ' , tester.predict('letter'))
            cv2.imshow('ASD',rect)
            start += 1
    if start == 0:
        start += 1
    old_x = x
    old_y = y
    old_x_w = x+w
    old_y_h = y+h
    
cv2.waitKey(0)
